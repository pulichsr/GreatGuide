package android.greatguide.csv;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import android.os.Environment;
import android.util.Log;
  
public class AuditTrail {
	
	private static final String TAG = "GPS";
	private static String csvFileName = null;

	/**
	 * 
	 * @param aString
	 * @return
	 */
	public static ActionResult record(String aString)  {

        ActionResult result = new ActionResult();

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd_MM_yyyy", Locale.ENGLISH);
        String currentDate = dateFormatter.format(cal.getTime());

        SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss",Locale.ENGLISH);
		String currentTime = timeFormatter.format(cal.getTime()) ;

		csvFileName = "audit_"+ currentDate + ".csv";

        try{
            String auditLocation = Environment.getExternalStorageDirectory() + "/audits/";
            File auditDirectory = new File(auditLocation);
            if (!auditDirectory.mkdir())
                auditLocation = Environment.getExternalStorageDirectory() + "/";

		    FileWriter writer = new FileWriter(auditLocation + csvFileName, true);
		
    		writer.append(aString);
	    	writer.append(',');
		    writer.append(currentDate);
		    writer.append(',');
		    writer.append(currentTime);
		    writer.append('\n');

		    writer.flush();
		    writer.close();

        }catch(Exception e){
        	result = new ActionResult(e);
        	Log.e(TAG, "Failed to write CSV File:  "+e);
        	
       }    

		return result;
	}
	

}
