package android.greatguide.csv;

/***
 *
 * Author: Lennie De Villiers
 * 26 Nov 2012
 */
public class ActionResult {

    private boolean successful = false;
    private String errorMessage = null;
    private Exception exceptionDetail = null;

    public ActionResult()
    {
        successful = true;
        errorMessage = null;
    }

    public ActionResult(boolean aSuccessful, String aErrorMessage)
    {
        successful = aSuccessful;
        errorMessage = aErrorMessage;
    }

    public ActionResult(Exception aException)
    {
        successful = false;
        exceptionDetail = aException;
    }

    public boolean isSuccessful() {
        return successful;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public Exception getExceptionDetail() {
        return exceptionDetail;
    }

    @Override
    public String toString()
    {
        StringBuilder st = new StringBuilder();
        st.append("Successful: ").append(successful).append(" ");
        if (errorMessage != null)  {
            st.append("Error Message: ").append(errorMessage).append(" ");
        }
        if (exceptionDetail != null) {
            st.append("Exception: ").append(exceptionDetail.getMessage()).append(" ");
        }
        return st.toString();
    }
}
