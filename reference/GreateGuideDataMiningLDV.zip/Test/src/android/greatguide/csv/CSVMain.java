package android.greatguide.csv;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class CSVMain extends Activity {

	@Override
	  public void onCreate(Bundle savedInstanceState) {
	      super.onCreate(savedInstanceState);
	      setContentView(R.layout.main);
	    
	      TextView myXmlContent = (TextView)findViewById(R.id.xml_tv);
	      
	      ActionResult result  = AuditTrail.record("Test");
	        
	       myXmlContent.setText(result.toString());
	  
	  }    

	  
	 
	}