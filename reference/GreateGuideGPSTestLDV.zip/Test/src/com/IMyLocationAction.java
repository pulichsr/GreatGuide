package com;

import android.app.Activity;

public interface IMyLocationAction {

	public void getCoordinates(Activity aActivity);
	public boolean registerListener(IMyLocationListener aListener);
    public boolean isGPSEnabled();
}
