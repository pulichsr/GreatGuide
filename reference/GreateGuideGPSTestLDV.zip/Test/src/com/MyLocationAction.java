package com;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;

import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

/**
 * Original Author: sandeep pulichintala
 * Author: Lennie De Villiers
 * 24 Nov 2012
 */
public class MyLocationAction implements IMyLocationAction {

	private List<IMyLocationListener> listeners = new ArrayList<IMyLocationListener>();
	private LocationManager gpslocManager = null;
	private LocationListener gpslocListener = null;
	private static final String TAG = "MyLocationAction";
	private List<MyLocation> locationsList = new ArrayList<MyLocation>();
    private Boolean gpsEnabled = false;
    private Location lastLocation = null;

    // Only detect GPS location every 30 seconds or 10 meters
    private final long LOCATION_DETECT_DELAY_SECONDS = 30000;
    private final float LOCATION_DETECT_DELAY_METERS = 10f;

	public void getCoordinates(Activity aActivity) {
		this.retrieveCoordinatesFromHardware(aActivity);
	}

	private void retrieveCoordinatesFromHardware(Activity aActivity) {

		gpslocListener = new GPSLocationListener();
        String provider = null;

		if (gpslocManager == null) {

            gpslocManager = (LocationManager) aActivity
                    .getSystemService(Context.LOCATION_SERVICE);
            Criteria criteriaFilter = new Criteria();
            criteriaFilter.setAccuracy(Criteria.ACCURACY_FINE);
            provider = gpslocManager.getBestProvider(criteriaFilter, true);
            lastLocation = gpslocManager.getLastKnownLocation(provider);
            if (lastLocation != null) {
                for (int i = 0; i < listeners.size(); i++) {
                    MyLocation loc = new MyLocation(lastLocation);
                    listeners.get(i).receiveMyLocation(loc, locationsList, false, loc.getLastUpdateDate());
                }
            }
		}

		gpslocManager.requestLocationUpdates(provider, LOCATION_DETECT_DELAY_SECONDS,
                LOCATION_DETECT_DELAY_METERS, gpslocListener);


        gpsEnabled = gpslocManager.isProviderEnabled(provider);
        if (gpsEnabled == false) {
           if (locationsList != null && locationsList.size() > 0) {
               for (int i = 0; i < listeners.size(); i++) {
                   listeners.get(i).failedToGetMyLocation(locationsList.get(0), locationsList);
               }
           }
           else {
               for (int i = 0; i < listeners.size(); i++) {
                   listeners.get(i).failedToGetMyLocation(null, null);
               }
           }
        }
	}

	private class GPSLocationListener implements LocationListener {

		public void onLocationChanged(Location newLocation) {

			if (newLocation != null) {
                MyLocation currentLocation = new MyLocation(newLocation);
				locationsList = UpdateGPSList.updateList(locationsList, currentLocation);
                for (int i = 0; i < listeners.size(); i++) {
                    listeners.get(i).receiveMyLocation(currentLocation, locationsList, false, currentLocation.getLastUpdateDate());
                }
            } else {
                if (locationsList != null && locationsList.size() > 0) {
                    for (int i = 0; i < listeners.size(); i++) {
                        listeners.get(i).receiveMyLocation(locationsList.get(0), locationsList, true, locationsList.get(0).getLastUpdateDate());
                    }
                }
                else {
                    if (locationsList != null && locationsList.size() > 0) {
                        for (int i = 0; i < listeners.size(); i++) {
                            listeners.get(i).failedToGetMyLocation(null, null);
                        }
                    }
                }
			}
		}

		public void onProviderDisabled(String provider) {

		}

		public void onProviderEnabled(String provider) {

		}

		public void onStatusChanged(String provider, int status, Bundle extras) {

		}
	}

	/**
	 * register the listener to receive the fired events
	 */
	public boolean registerListener(IMyLocationListener aListener) {
		return listeners.add(aListener);
	}

    public boolean isGPSEnabled()
    {
        return gpsEnabled;
    }
}

