package com;

import android.location.Location;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * Author: Lennie De Villiers
 * Created Date: 24 Nov 2012
 *
 */
public class MyLocation extends Location {

    private String locationName = null;
    private Date lastUpdateDate = null;

    public MyLocation()
    {
        super("mock");
    }

    public MyLocation(Location aLocation)
    {
        super(aLocation);
        this.lastUpdateDate = new Date();
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    /**
     *
     * Set the last date/time the coordinates was updated
     *
     * @param aDate
     */
    public void setLastUpdateDate(Date aDate)
    {
        this.lastUpdateDate = aDate;
    }

    /**
     *
     * Get the last date/time the coordinates was updated
     *
     * @return
     */
    public Date getLastUpdateDate()
    {
        return this.lastUpdateDate;
    }

    /**
     *
     * Get the last date/time the coordinate was updated for display purpose
     *
     * @return
     */
    public String getDisplayUpdateDate()
    {
        String result = null;
        try
        {
            // TODO: We might wanna read this date format from a settings file?
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
            result = df.format(this.lastUpdateDate);
        }
        catch (Exception e) {
           // We don't care about errors here
        }
        return result;
    }

    @Override
    public String toString()
    {
        return "Lat: " + this.getLatitude() + " Long: " + this.getLongitude() ;
    }
}
