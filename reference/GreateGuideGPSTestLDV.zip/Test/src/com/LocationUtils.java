package com;

import android.location.Location;

/**
 *
 * Author: Lennie De Villiers
 * Created: 21 Nov 2012
 */
public class LocationUtils {

    private final static float KILOMETERS_IN_METERS = 1000f;
    private final static float AVERAGE_WALKING_SPEED = 1.4f; //as seen on google

    /**
     *
     * Calculate the distance between two start + end latitude and longitude coordinates
     * Return distance in meters
     *
     * @param aStartLat
     * @param aStartLong
     * @param aEndLat
     * @param aEndLong
     * @return
     */
    public static float calculateDistance(double aStartLat, double aStartLong, double aEndLat, double aEndLong) {

        float[] distance = new float[3]; //magic number used for debugging perposes

        Location.distanceBetween(aStartLat, aStartLong, aEndLat, aEndLong ,distance);

        return (distance[0]);
    }


    /***
     *
     * Calculate the average walking speed in seconds
     * This is the average speed it will take a person to walk from two start + end latitude and longitude coordinates
     *
     * @param aStartLat
     * @param aStartLong
     * @param aEndLat
     * @param aEndLong
     * @return
     */
    public static float calculateAverageWalkingSpeedInSeconds(double aStartLat, double aStartLong, double aEndLat, double aEndLong)
    {
        float distance = calculateDistance(aStartLat, aStartLong, aEndLat, aEndLong);
        float timeInSeconds = (distance /  AVERAGE_WALKING_SPEED);
        return timeInSeconds;
    }


    /***
     *
     * Calculate the average walking speed in minutes;
     * This is the average speed it will take a person to walk from two start + end latitude and longitude coordinates
     *
     * @param aStartLat
     * @param aStartLong
     * @param aEndLat
     * @param aEndLong
     * @return
     */
    public static float calculateAverageWalkingSpeedInMinutes(double aStartLat, double aStartLong, double aEndLat, double aEndLong)
    {
        float timeInSeconds = calculateAverageWalkingSpeedInSeconds(aStartLat, aStartLong, aEndLat, aEndLong);
       return timeInSeconds / 60;
    }

    /**
     *
     * Convert meters into kilometers
     *
     * @param aMeters
     * @return
     */
    public static float metersToKilometers(double aMeters)
    {
          return (float) aMeters / KILOMETERS_IN_METERS;
    }
}
