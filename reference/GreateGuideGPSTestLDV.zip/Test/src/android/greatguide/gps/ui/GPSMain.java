package android.greatguide.gps.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.app.ListActivity;
import android.greatguide.gps.*;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.*;

public class GPSMain extends ListActivity implements IMyLocationListener, OnClickListener {

    private final boolean MOCK_MODE = false;

	private IMyLocationAction myLocation = null;
	private Button retrieveLocationButton = null;
	private static final String TAG = "GPSMain";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.location_list);

        if (MOCK_MODE) {
	        myLocation = new MockMyLocationAction();
        }
        else {
            myLocation = new MyLocationAction();
        }

        myLocation.registerListener(this);

		retrieveLocationButton = (Button) findViewById(R.id.retrieve_location_button);
		retrieveLocationButton.setOnClickListener(this);
    }

	public void onClick(View arg0) {
        myLocation.getCoordinates(this);
        TextView vw = (TextView) findViewById(R.id.gpsInfo);
        vw.setText("GPS Location: " + myLocation.isGPSEnabled());
    }

	public void receiveMyLocation(MyLocation aCurrentLocation,
                                  List<MyLocation> aLocationsList, boolean aCache, Date aLastUpdatedDate) {

		Log.i(TAG, "Successfuly got the Coordinates");
        Toast.makeText(getApplicationContext(), "List size: " + aLocationsList.size(),
                Toast.LENGTH_SHORT).show();

        TextView vw = (TextView) findViewById(R.id.gpsInfo);

		vw.setText("Lat: " +  aCurrentLocation.getLatitude() + " Long: " + aCurrentLocation.getLongitude()
				+" LUD: " + aCurrentLocation.getDisplayUpdateDate() + " Cache: " + aCache);

        displayRecentLocations(aLocationsList);
		
	}

    @Override
    public void failedToGetMyLocation(MyLocation aLastLocationFound, List<MyLocation> aLocationsList) {
        Log.i(TAG, "Failed to get the Coordinates");

        if (aLastLocationFound != null) {
            Toast.makeText(getApplicationContext(), "Failed to get the Coordinates, " +  aLastLocationFound.toString(),
                Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(getApplicationContext(), "Failed to get the Coordinates, No location",
                    Toast.LENGTH_SHORT).show();
        }

        if (aLocationsList != null && aLocationsList.size() > 0)
        {
            displayRecentLocations(aLocationsList);
        }
    }

    private void displayRecentLocations(List<MyLocation> aLocationsList) {
        List<String> displayLocations = new ArrayList<String>();
        for (MyLocation currentLocation : aLocationsList) {
            StringBuilder st = new StringBuilder();
            if (currentLocation.getLocationName() != null) {
                st.append("Name: ").append(currentLocation.getLocationName()).append(" ");
            }

            st.append("Lat: ").append(currentLocation.getLatitude()).append(" ");
            st.append("Long: ").append(currentLocation.getLongitude()).append(" ");
            st.append("LUD: ").append(currentLocation.getDisplayUpdateDate()).append(" ");
            displayLocations.add(st.toString());
        }

        if (displayLocations != null && displayLocations.size() > 0) {
            ArrayAdapter<String> locationList = new ArrayAdapter<String>(this, R.layout.location_item, displayLocations);
            setListAdapter(locationList);
        }
    }

}
